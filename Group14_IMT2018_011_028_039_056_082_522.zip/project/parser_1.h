#include <bits/stdc++.h>
#include "Variable.h"
#ifndef parser_h
#define parser_h
using namespace std;

//inherting Varibale class to store coefficients after parsing.

class parser_1: public Variable{
	string str;
	public:
		parser_1();
		~parser_1();
		parser_1(string equation);
		void get_coeff();
		void set_string(string eq);
};

#endif
