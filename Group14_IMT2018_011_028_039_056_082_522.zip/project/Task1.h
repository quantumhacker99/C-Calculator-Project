#include "parser.h"
#ifndef TASK1_H
#define TASK1_H

using namespace std;

class Task1{
	float _a,_b,_c;				//Using pointer to parser object to solve Task 1
	int _equalsindex;
	parser *_parse;
	public:
		Task1(string s);
		void solve_eq();
};

#endif
