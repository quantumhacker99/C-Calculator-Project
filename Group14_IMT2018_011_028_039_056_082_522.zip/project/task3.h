#pragma once
#include "parser_1.h"
#include "Variable.h"
#include <iostream>
#include <vector>

using namespace std;

class task3 : public parser_1{
	
	public:
		task3(string equ);
		~task3();
		string getsolution();   
		vector<float> value;       // used when derived class needs solution of the equation.
		string equation;
};
