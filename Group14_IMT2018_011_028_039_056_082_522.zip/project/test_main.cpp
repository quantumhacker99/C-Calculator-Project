#include "Equation.h"

using namespace std;

int main(){
	string s;
	cin >> s;
	Equation eq(s);
	eq.solve_equation();
	return 0;
}
