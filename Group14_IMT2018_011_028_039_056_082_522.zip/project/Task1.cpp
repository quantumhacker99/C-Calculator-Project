#include "Task1.h"

using namespace std;

Task1::Task1(string s){
	_equalsindex = s.find('=');				//Storing index of '='
        _parse = new parser(s.substr(0,_equalsindex),'x');	//Passes LHS to parser object
        _c = stof(s.substr(_equalsindex+1));			//To calculate RHS
        _a = _parse -> get_a();					//Storing coefficient of x
        _b = _parse -> get_b();					//Storing constant
}

void Task1::solve_eq(){
	if( _a == 0){
		if( _c == _b){
			cout << "All real numbers satisfy this equation"<<endl;		//Checking for infinite solutions
		}
		else
			cout <<"We can't handle this"<<endl;				//If c!=b then no solution
	}
	else{
		float soln = (_c-_b)/_a;
		if( soln == -0){
			cout <<0<<endl;
		}
		else{
			cout << fixed;					//Printing till 4 digits after decimal place
			cout << setprecision(4);
			cout <<"x="<<(_c-_b)/_a<<endl;
		}
	}
}


