#ifndef VAR_H
#define VAR_H

class Variable{
	float _x;
	float _y;
	float _z;
	float _x2;
	float _sinx;
	float _cosx;
	float _log;
	float _constant;
	public:
		Variable();

		float get_x();
		float get_y();
		float get_z();
		float get_x2();
		float get_sinx();
		float get_cosx();
		float get_log();
		float get_constant();

		void set_x(float x);
		void set_y(float y);
		void set_z(float z);
		void set_x2(float x2);
		void set_sinx(float sinx);
		void set_cosx(float cosx);
		void set_log(float log);
		void set_constant(float constant);

};

#endif
