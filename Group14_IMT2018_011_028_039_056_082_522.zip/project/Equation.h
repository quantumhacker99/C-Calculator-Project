#include <bits/stdc++.h>
//Include all files here
#include "Task1.h"
#include "Task9.h"
#include "task3.h"
#include "Task2.h"
#include "Task4.h"
#include "task8.h"
#ifndef EQUATION_H
#define EQUATION_H

using namespace std;


class Equation{
	string _s;
	public:
		Equation(string s);		
		bool contain(string s,char c);
		void solve_equation();
};

#endif
