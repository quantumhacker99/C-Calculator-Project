
/*
	Author : Prajwal Agarwal (IMT2018056)
	
*/

#include<bits/stdc++.h>
using namespace std;
#include"Variable.h"
#include"Task4.h"

/*
	Some Example To Play With:

	x^2+2x+1=0
	x^2-2x+1=0
	21x^2+190x+90=0
	-2x+2x^2-10=0
	-100+2x+2x^2=0
	
	-100+2x+2x^2=x+x^2
	2x^2+3x+2=x^2+x+1

	x^2+x+1=0
	x^2+x+1=x^2+1+x
	x^2+x+10=x^2+x

	2x+1=0
	x+1=9
	2x+1=3x+2

*/

Task4::Task4(string s){
	coeffOfx2 = 0;
	coeffOfx = 0;
	constant = 0;
	discriminant = 0.0;
	this->s = s;
}
Task4::Task4(string s,float a,float b,float c){
	this->s = s;
	coeffOfx2 = a;
	coeffOfx = b;
	constant = c;
	discriminant = 0.0;
}
void Task4::calDiscriminant(){
	this->discriminant = (coeffOfx*coeffOfx) - (4*coeffOfx2*constant);
}
double Task4::getDiscriminant(){
	return this->discriminant;
}
void Task4::setX(float val){
	this->coeffOfx = val;
}
void Task4::setX2(float val){
	this->coeffOfx2 = val;
}
void Task4::setConstant(float val){
	this->constant = val;
}
pair<double, double> Task4::calculateOutput(){
	calDiscriminant();
	double delta = sqrt(this->discriminant);
	double ans1 = (-coeffOfx+delta)/(2*coeffOfx2);
	double ans2 = (-coeffOfx-delta)/(2*coeffOfx2);
	pair<double, double> solution = make_pair(ans1, ans2);
	return solution;
}
void Task4::printOutput(){
	this->calDiscriminant();
	if(coeffOfx2 == 0 && coeffOfx == 0){
		if(constant == 0)
			cout << "Infinite Solutions" << endl;
		else
			cout << "No solution" << endl;
		}
	else if(coeffOfx2 == 0){
		cout << fixed << setprecision(4) << "x="<< ((-1.0*constant)/coeffOfx) << endl;
		return;
	}
	else if(getDiscriminant() >= 0){
		pair<double, double> solution = calculateOutput();
		if(solution.first == 0.0){
			solution.first = abs(solution.first);
		}
		if(solution.second == 0.0){
			solution.second = abs(solution.second);
		}
		cout << fixed << setprecision(4) << "x="<<solution.first << ";" << "x=" << solution.second << endl;
	}
	else{
		cout << "No solution" << endl;
	}
}
void Task4::processInput(string s, Variable* variables){
	if(s[0]!='-'){
		s = '+' + s;
	}
	int n = s.size();
	int limit = 0;
	for(int i = 0; i < n ; i ++){
		if(s[i] == '='){
			limit = i+1;
			break;
		}
	}
	int i = 0;
	while(i<limit){
		if(s[i]=='=')
			break;
		string c = "";	
		int sign = 1;
		if(s[i] == '-')
			sign = -1;
		i ++;
		while(i<n && ((s[i]>='0' && s[i]<='9'))||(s[i]=='.')){
			c += s[i];
			i ++;
		}
		if(i<(n-1) && s[i] == 'x' && s[i+1]=='^'){
			float choice = c.size()>0 ? (sign*stof(c)) : 1*sign;
			variables->set_x2(choice);
			i+=3;
		}
		else if(i<(n-1) && s[i]=='x'){
			float choice = c.size()>0 ? (sign*stof(c)) : 1*sign;
			variables->set_x(choice); 
			i += 1;
		}
		else if(i<(n-1) && (s[i]=='+' || s[i]=='=' || s[i] == '-')){
			float choice  = c.size()>0 ? sign*stof(c) : 0; 
			variables->set_constant(choice);
		}
	}
	Variable* v2 = new Variable();
	i = 0;
	s = s.substr(limit);
	if(s[0]!='-'){
		s = '+' + s;
	}
	s += " ";
	n = s.size();
	while(i<n){
		if(s[i] == ' ')
			break;
		string c = "";	
		int sign = 1;
		if(s[i] == '-')
			sign = -1;
		i ++;
		while(i<n && ((s[i]>='0' && s[i]<='9')||(s[i]=='.'))){
			c += s[i];
			i ++;
		}
		if(i<(n-1) && s[i] == 'x' && s[i+1]=='^'){
			float choice = c.size()>0 ? (sign*stof(c)) : 1*sign;
			v2->set_x2(choice);
			i+=3;
		}
		else if(i<(n-1) && s[i]=='x'){
			float choice  = c.size()>0 ? (sign*stof(c)) : 1*sign;
			v2->set_x(choice);
			i += 1;
		}
		else if(i<n && (s[i]=='+' || s[i] == '-' || s[i] == ' ')){
			float choice  = c.size()>0 ? sign*stof(c) : 0;
			v2->set_constant(choice);
		}
	}
	variables->set_x(variables->get_x() - v2->get_x());
	variables->set_x2(variables->get_x2() - v2->get_x2());
	variables->set_constant(variables->get_constant() - v2->get_constant());
}
