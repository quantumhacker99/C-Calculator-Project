#include <bits/stdc++.h>
#include "Variable.h"
#ifndef PARSER_H
#define PARSER_H
using namespace std;

class parser{
    protected:
        char _ch;				//Used to store the variable name, like 'x' or 'y'
        Variable *_v;				//Pointer pointing to Variable object
        string _s;				//Used to store the string
        bool _flag;				//Checks if coefficient of variable is implicitly defined as 1/-1 or explicitly given
        int _varindex,_operatorindex;		//To store index of variable and operator
        

        bool check_for_op();			

        bool if_sub();

        void calc_a();

        void calc_b();

    public:
	parser();
        parser(string s,char ch);
        void reverse_string();
        float get_a();
        float get_b();
};

#endif
