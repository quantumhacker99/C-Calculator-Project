#include "task3.h"
#include <bits/stdc++.h>
#include <string.h>
#include <iostream>

task3 :: task3(string equ){
	equation=equ;
}
// Destructor.
task3 :: ~task3(){
}

// splits lhs and rhs
// gets individual coefficients to solve the equation.

string task3::getsolution(){
	ostringstream ss;
	string lhs,rhs;
	int i;
	for(i=0;i<equation.length();i++){
		if(equation[i]=='='){
			break;
		}
	}
	lhs=equation.substr(0,i);
	lhs.append("=");
	rhs=equation.substr(i+1,equation.length()-i-1);
	rhs.append("=");
	parser_1 *l=new parser_1(lhs);
	parser_1 *r=new parser_1(rhs);
	double solution;
	l->get_coeff();
	r->get_coeff();
	if( (l->get_x()-r->get_x() ) == 0 && (l->get_constant()-r->get_constant() )==0){
		return ("INFINITE SOLUTIONS");
		value.push_back(0);             /*   */
	}
	else if( (l->get_x()-r->get_x()) ==0 && ( r->get_constant() - r->get_constant() )!=0){
		return ("NO SLOUTION");
	}
	else{
		solution = (r->get_constant()-l->get_constant() )/(float) (l->get_x()-r->get_x() );
		if(solution == 0)
			solution = 0;
		float rounded = (int)(solution*10000.0)/10000.0;
		ss << rounded;
		value.push_back(0);             /*    */
		value.push_back(rounded);       /*    */
		return ("x=" + ss.str());
	}
}
/* vector<int> value is used when other class inherits this class to get the solution.
   1. If   value.size() == 0       =>        No Solution.
   2. If   value.size() == 1       =>        Infinite Solution.
   3. If   value.size() == 2       =>        value[1] is the solution for the given equation.
*/
