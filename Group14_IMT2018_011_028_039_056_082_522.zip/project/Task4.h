
/*
	Author : Prajwal Agarwal (IMT2018056)
	
*/

#pragma once
#include<bits/stdc++.h>
using namespace std;
#include"Equation.h"
#include"Variable.h"

class Task4{
private:
	float coeffOfx2;
	float coeffOfx;
	float constant;
	double discriminant;
	string s;
public:
	Task4(string s);
	Task4(string s,float a,float b,float c);
	~Task4();
	void setX(float);
	void setX2(float);
	void setConstant(float);
	void processInput(string s, Variable* variables);
	void calDiscriminant();
	pair<double, double> calculateOutput();
	void printOutput();
	double getDiscriminant();
};