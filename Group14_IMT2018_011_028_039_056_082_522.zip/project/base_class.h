#pragma once
#include<bits/stdc++.h>
using namespace std;
#include"Variable.h"

class base_class{
private:
	string _s;
public:
	base_class(string s){
		_s = s;
	}
	virtual float processInput()=0;
};
