#include<iostream>
#include<string>
#include"parser.h"
#include"Task2.h"
using namespace std;

Task2::Task2(string s)
{
    _str = s;               
    solve();                //calling solve() in the constructor
}

Task2::~Task2()
{

}

void Task2::solve()
{

    int semi_colon,equals_to1,equals_to2;                               // equals_to1 is equal to in equation 1  and equation_to2 similarly;
    string e1,e2,e1_lhs_x,e2_lhs_x,e1_lhs_y,e2_lhs_y;                   //e1,e2 are the two equations. e1_lhs_x is lhs equation of e1 till it encounters x;
    float a1,a2,b1,b2,c1,c2;                                            // all the coefficients;                                   
    
    semi_colon = _str.find(';');
    e1 = _str.substr(0,semi_colon);
    e2 = _str.substr(semi_colon+1,(_str.length()-(semi_colon + 1)));
    equals_to1 = e1.find('=');
    equals_to2 = e2.find('=');
    e1_lhs_y = e1.substr(0,e1.find('y'));
    e2_lhs_y = e2.substr(0,e2.find('y'));
    e1_lhs_x = e1.substr(0,e1.find('x'));
    e2_lhs_x = e2.substr(0,e2.find('x'));
    
    
    
    if(e1.find('x') < e1.find('y'))                                 // x comes before y in equation 1;
    {
        if(e1.at(equals_to1 - 3) == 'x' )                           // if +y or -y is given instead of +1y or -1y 
        {
            if(e1.at(equals_to1 - 2) == '+' || e1.at(equals_to1 - 2) == '-')
            {
                string dupe1 = e1; 
                dupe1.insert(equals_to1-1,"1");
                e1_lhs_y = dupe1.substr(0,dupe1.find('y'));
            }
        }
        parser p1(e1_lhs_y,'x');

        a1 = p1.get_a();
        b1 = p1.get_b();
        c1 = stof(e1.substr(equals_to1+1));

    }

    else if(e1.find('x') > e1.find('y'))                            // y comes before x in equation 1;
    {
        if(e1.at(equals_to1 - 3) == 'y' )                           // if +x or -x is given instead of +1x or -1x
        {
            if(e1.at(equals_to1 - 2) == '+' || e1.at(equals_to1 - 2) == '-')
            {
                string dupe1 = e1;
                dupe1.insert(equals_to1-1,"1");
                e1_lhs_x = dupe1.substr(0,dupe1.find('x'));
            }
        }
        parser p2(e1_lhs_x,'y');

        b1 = p2.get_a();
        a1 = p2.get_b();
        c1 = stof(e1.substr(equals_to1+1));

    }

    if(e2.find('x') < e2.find('y'))                                     // x comes before y in equation 2;
    {
        if(e2.at(equals_to2 - 3) == 'x' )                               // if +y or -y is given instead of +1y or -1y
        {
            if(e2.at(equals_to2 - 2) == '+' || e2.at(equals_to2 - 2) == '-')
            {
                string dupe2 =e2;
                dupe2.insert(equals_to2-1,"1");
                e2_lhs_y = dupe2.substr(0,dupe2.find('y'));
            }
        }
        parser p3(e2_lhs_y,'x');

        a2 = p3.get_a();
        b2 = p3.get_b();
        c2 = stof(e2.substr(equals_to2+1));
    }

    else if(e2.find('x') > e2.find('y'))                                // y comes before x in equation 2
    {
        if(e2.at(equals_to2 - 3) == 'y' )                               // if +y or -y is given instead of +1y or -1y
        {
            if(e2.at(equals_to2 - 2) == '+' || e2.at(equals_to2 - 2) == '-')
            {
                string dupe2 = e2;
                dupe2.insert(equals_to2-1,"1");
                e2_lhs_x = dupe2.substr(0,dupe2.find('x'));
            }
        }
        parser p4(e2_lhs_x,'y');

        b2 = p4.get_a();
        a2 = p4.get_b();
        c2 = stof(e2.substr(equals_to2+1));

    }




    if(((a1*b2) - (a2*b1)) == 0 )                                   // if a1*b2 = a2*b1 then check if c1%c2 = 0. if yes then (infinite solutions) else (no solution)
    {
        if((int)c1 % (int)c2 == 0 || (int)c2 % (int)c1 ==0)
        {
            cout << "infinite solutions" << endl;
        }
        else
        {
            cout << "no solution " << endl;
        }
    }

    else if(e1.find('x') != e1.npos && e1.find('y') != e1.npos && e2.find('x') != e2.npos && e1.find('y') != e2.npos)
    {                                                                                                                          // check if equations have x and y variables properly
        cout << "x=";
        cout << (b2*c1 - b1*c2) / (a1*b2 - a2*b1);
        cout <<";";
        cout << "y=";
        cout << (a1*c2 - a2*c1) / (a1*b2 - a2*b1);
        cout<<endl;
    }

    else
    {
        cout << "Invalid Input" << endl ;
    }

}