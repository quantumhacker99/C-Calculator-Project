#ifndef Task_H_
#define Task_H_
#include "parser.h"
#include <bits/stdc++.h>
using namespace std;
class Task9
{
public:
    Task9(string s);
    ~Task9();
    bool findSol(string s, int f);
    vector<float> getV() { return _v; }
    string getString() { return _s; }
    void getSol(bool, bool);

protected:
    string _s;
    vector<float> _v;
};
#endif