#include "Equation.h"
#include"Variable.h"

using namespace std;


Equation::Equation(string s){
	_s = s;
}
	
bool Equation::contain(string s,char c){
	if(s.find(c) >=0 && s.find(c) <= s.size())
		return true;
	return false;
}

void Equation::solve_equation(){
	if( Equation::contain(_s,'y')){
		Task2 task2(_s);
	}
	else if(Equation::contain(_s,'^')){
			Variable* v = new Variable();
			Task4* qe = new Task4(_s);
			qe->processInput(_s, v);
			qe->setX2(v->get_x2());
			qe->setX(v->get_x());
			qe->setConstant(v->get_constant());
			qe->printOutput();
	}
	else if(Equation::contain(_s,'l')){
		task8* t = new task8(_s);
    	t->task();
   		cout << fixed << setprecision(4) << t->get_sol() << endl;
	}
	else if(Equation::contain(_s,'|')){
		Task9 task(_s);
	}
	else if(Equation::contain(_s.substr(_s.find('=')) , 'x')){
		task3 task3(_s);
		cout<< fixed << setprecision(4) << task3.getsolution()<<endl;
	}
	else{
		Task1 task1(_s);
		task1.solve_eq();
	}
}
