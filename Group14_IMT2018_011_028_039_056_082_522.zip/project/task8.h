#pragma once
#include<iostream>
#include<math.h>
#include<string.h>
#include <sstream> 
#include <bits/stdc++.h> 
#include "Variable.h"
#include"parser.h"


using namespace std;


class logarithm
{
    string sol;
    int task;
    string eq;
    public:
    logarithm(string s);
    string get_eq();

    void set_sol(string s);
    string get_sol();

};

class task8 : public logarithm
{
    public:
    using logarithm :: logarithm;

    Variable* linear1D(string l);
    void task();
};