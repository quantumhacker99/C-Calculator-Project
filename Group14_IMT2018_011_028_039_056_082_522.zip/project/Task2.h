#ifndef TASK2_H
#define TASK2_H
#include<string>
using namespace std;
class Task2
{
    private:
        string _str;
    public:
        Task2(string s);
        ~Task2();
        void solve();

};
#endif