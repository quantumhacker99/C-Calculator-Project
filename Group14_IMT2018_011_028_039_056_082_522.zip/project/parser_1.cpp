#include "parser_1.h"
#include <string.h>
#include <iostream>
#include <bits/stdc++.h>
using namespace std;

parser_1::parser_1(){
}
// Destructor
parser_1::~parser_1(){
}

parser_1::parser_1(string equation){
	set_string(equation);
}
void parser_1::set_string(string eq){
	str=eq;
}

/* Runs through each character and accumulates its coefficient 
   sets accumulated coefficients in _x and _constant.  */
 
void parser_1::get_coeff(){
	float a1=0.0,b1=0.0;
	float a2=0.0,b2=0.0;
	int j=0;
	int flag=2;
	for(int i=0;i<str.size();i++){
		if(str[j]=='='){
			break;
		}
		if(str[i]=='+' || str[i]=='-' || str[i]=='='){
			for(int k=j;k<i;k++){
				if(str[k]=='x'){	
					if(str[j]=='x'){
						a1=1;
					}
					else if(str[j]=='-' && (str[j+1] < 48 || str[j+1] > 57)){
						a1=-1;
					} 
					else if(str[j]=='-'){
						a1=stod(str.substr(j+1,k-j-1));
						a1=-a1;
					}
					else if(str[j]=='+'){
						a1=stod(str.substr(j+1,i-j-1));
					}
					else{
						a1=stod(str.substr(j,i-j-1));
					}
					flag=1;
					a2+=a1;
				}
				else
					flag=0;
			}
		}
		if(flag==0 && (str[i]=='+' || str[i]=='-' || str[i]=='=') ){
			if(str[j]=='-'){
				b1=stod(str.substr(j+1,i-j-1));
				b1=-b1;
			}
			else if(str[j]=='+'){
				b1=stod(str.substr(j+1,i-j-1));
			}
			else{
				b1=stod(str.substr(j,i-j));
			}
			b2+=b1;
		}
	
		if(str[i]=='+' || str[i]=='-'){
			j=i;
		}
	
	}
	set_x(a2); // setting coefficients.
	set_constant(b2); // setting constant.
}
