#include "Variable.h"	
Variable::Variable(){
	_x = 0;
	_y = 0;
	_z = 0;
	_x2 = 0;
	_sinx = 0;
	_cosx = 0;
	_log = 0;
	_constant = 0;
}

float Variable::get_x(){
	return _x;
}

float Variable::get_y(){
	return _y;
}

float Variable::get_z(){
	return _z;
}

float Variable::get_x2(){
	return _x2;
}

float Variable::get_sinx(){
	return _sinx;
}

float Variable::get_cosx(){
	return _cosx;
}

float Variable::get_log(){
	return _log;
}	

float Variable::get_constant(){
	return _constant;
}

void Variable::set_x(float x){
	_x = x;
}

void Variable::set_y(float y){
	_y = y;
}

void Variable::set_z(float z){
	_z = z;
}

void Variable::set_x2(float x2){
	_x2 = x2;
}

void Variable::set_sinx(float sinx){
	_sinx = sinx;
}

void Variable::set_cosx(float cosx){
	_cosx = cosx;
}

void Variable::set_log(float log){
	_log = log;
}

void Variable::set_constant(float constant){
	_constant = constant;
}




