#include "Task9.h"
#include "Variable.h"
Task9::Task9(string s)
{
    string c = s;
    c.erase(c.begin()); //removing first mod from equation
    int i = 0;
    while (c[i] != '|')
    {
        i++;
    }
    c.erase(c.begin() + i); //removing the second mod from equation
    _s = c;
    bool t1, t2;
    t1 = findSol(getString(), 0); //for positive mod opening; calling the function to calculate solution
    t2 = findSol(getString(), 1); //for negative mod opening; calling the function to calculate solution
    getSol(t1, t2);               //printing the solution
};
Task9::~Task9(){};
bool Task9::findSol(string s, int f)
{
    Variable var, var1; //To store the coefficients
    string s1, s2;
    int equalsindex = s.find('=');
    //For LHS
    parser parse(s.substr(0, equalsindex), 'x');
    var.set_x(parse.get_a());
    var.set_constant(parse.get_b());
    //For RHS
    parser parse1(s.substr(equalsindex + 1), 'x');
    var1.set_x(parse1.get_a());
    var1.set_constant(parse1.get_b());
    float ans = 0;
    //For positive mode opening
    if (f == 0)
    {
        if (var.get_x() == var1.get_x()) //If Coefficients of both the x's are same
        {
            return false;
        }
        else
        {
            ans = (var1.get_constant() - var.get_constant()) / (var.get_x() - var1.get_x()); //(d-b)/(a-c)
            if (ans > -var.get_constant() / var.get_x())
            {
                _v.push_back(ans); //valid ans
                return true;
            }
            else
            {
                _v.push_back(ans); //Invalid ans
                return false;
            }
        }
    }
    //For negative mod opening
    else
    {
        Variable var2;
        var2.set_x(var.get_x() - 2 * var.get_x());
        var2.set_constant(var.get_constant() - 2 * var.get_constant());
        if (var2.get_x() == var1.get_x())
        {
            return false;
        }
        else
        {
            ans = (var1.get_constant() - var2.get_constant()) / (var2.get_x() - var1.get_x());
            if (ans < -var.get_constant() / var.get_x())
            {
                _v.push_back(ans);
                return true;
            }
            else
            {
                _v.push_back(ans);
                return false;
            }
        }
    }
}
void Task9::getSol(bool t1, bool t2)
{
    //if both eqautions have valid solutions
    if (t1 && t2)
    {
        vector<float> v = getV();
        cout << "x=" << setprecision(4) << v[0] << ";x=" << fixed << setprecision(4) << v[1] << endl;
    }
    else
    {
        vector<float> v = getV();
        //If only equation 1 has valid solution
        if (t1)
        {
            cout << "x=" << setprecision(4) << v[0] << ";invalid:x=" << fixed << setprecision(4) << v[1] << endl;
        }
        //If only equation 2 has valid solution
        else if (t2)
        {
            cout << "x=" << setprecision(4) << v[1] << ";invalid:x=" << fixed << setprecision(4) << v[0] << endl;
        }
        //If both have invalid solutions
        else
        {
            cout << "No Solution" << endl;
        }
    }
}