#include<iostream>
#include<math.h>
#include<string.h>
#include <sstream> 
#include <bits/stdc++.h> 
#include "Variable.h"
#include"parser.h"
#include"task8.h"


using namespace std;




    logarithm :: logarithm(string s)
    {
        this->eq = s;
        if(s[0] == 'l' && s[1] == 'n' )
        {
            if(s[s.find(")") +1] != '=')
            {
                task = 8;
            }
            
        }
    }
    string logarithm ::  get_eq()
    {
        return this->eq;
    }
    void logarithm :: set_sol(string s)
    {
        this->sol = s;
    }
    string  logarithm :: get_sol()
    {
        return this->sol;
    }



    Variable*  task8 :: linear1D(string l)
    {

        Variable* a = new Variable;
        parser* p = new parser(l,'x');
        a->set_constant(p->get_b());
        a->set_x(p->get_a()) ;
        return a;
        
    }
    void task8 ::  task()
    {

        int index1 = this->get_eq().find('(');
        int index2 = this->get_eq().find(')');

        int signindex = index2 +1;
        
        string sub1 = this->get_eq().substr(index1 +1, index2-index1 -1);
        
        index1 = this->get_eq().find('(',index2 +1);
        index2 = this->get_eq().find(')',index1);

        string sub2 = this->get_eq().substr(index1 +1, index2-index1 -1);

        Variable *A1 = linear1D(sub1);
        Variable *A2 = linear1D(sub2);
        
        int index3 = this->get_eq().find('=');

        string sub3 = this->get_eq().substr(index3 + 1);

        stringstream str(sub3);
        float e = 0;
        str >> e;
        e = exp(e);

        if(this->get_eq()[signindex] == '-')
        {
            string x = "";
            float sol = ( A2->get_constant()*e - A1->get_constant() ) / (A1->get_x() - A2->get_x()*e );
            if( A1->get_x()*sol + A1->get_constant() > 0 && A2->get_x()*sol + A2->get_constant() > 0)
            {
                x = x + "x=" + to_string(sol);
            }
            this->set_sol(x);

        }
        else
        {
            Variable* co = new Variable;
            co->set_x2(A1->get_x()*A2->get_x());
            co->set_constant(A1->get_constant()*A2->get_constant() - e);
            co->set_x(A1->get_constant()*A2->get_x() + A1->get_x()*A2->get_constant());

            float dis = co->get_x()*co->get_x() - 4*co->get_x2()*co->get_constant();

            float b2a = -co->get_x()/(2*co->get_x2());
            if(dis>0)
            {
                float sol1 = b2a - sqrt(dis)/(2*co->get_x2());
                float sol2 = b2a + sqrt(dis)/(2*co->get_x2());
                string x = "";
                if( A1->get_x()*sol1 + A1->get_constant() > 0 && A2->get_x()*sol1 + A2->get_constant() > 0)
                {
                    x = x + "x=" + to_string(sol1) + ";";
                }
                
                if( A1->get_x()*sol2 + A1->get_constant() > 0 && A2->get_x()*sol2 + A2->get_constant() > 0)
                {
                    x = x + "x=" + to_string(sol2);
                }
                
                this->set_sol(x);
            } 
            else if(dis == 0)
            {
                if( A1->get_x()*b2a + A1->get_constant() > 0 && A2->get_x()*b2a + A2->get_constant() > 0)
                {
                    this->set_sol("x=" + to_string(b2a));
                }
                else 
                {
                    this->set_sol("");
                }
                
            }
            else
            {
                string x = "x=" + to_string(b2a) +"+i" + to_string(sqrt(-dis)/(2*co->get_x2())) + ";x=" +to_string(b2a) + "-i" + to_string(sqrt(-dis)/(2*co->get_x2()));
                this->set_sol(x);
            }
        
        }

    }
