#include "parser.h"
#include <bits/stdc++.h>

using namespace std;


parser::parser(){							//Default constructor
}
parser::parser(string s,char ch){					//Constructor
		_s = s;
		_v = new Variable();
		_varindex = s.find(ch);
		_ch = ch;
		_flag=0; 
}

bool parser::check_for_op(){						//Checking for operator symbol ie '+' or '-'. 
	if ( _varindex == _s.size()-1)
		return false;
	_operatorindex = _varindex+1;
        return true;
}

bool parser::if_sub(){							//Checking if there is a subtraction operation
	bool check_subtract = false;
        int i=0,j=0;
        if(check_for_op()){
        	if( _s[_operatorindex] == '-'){
			check_subtract = true;
                        _s[_operatorindex] = '+';
                }
         }
         return check_subtract;
}

void parser::calc_a(){							//Finding coefficient of the variable and storing in the Variable object pointed to by the pointer
	reverse_string();
	if(_varindex==0){
		_v->set_x(1);
	}
	else if(_varindex==1 && _flag==1){
		_v->set_x(-1);
	}	
	else if(_s[0]== '-' && _varindex==1){
		_v->set_x(-1);
	}
	else	
	        _v->set_x(stof(_s.substr(0,_varindex)));
	
}

void parser::calc_b(){							//Finding the constant term and storing in the Variable object pointed to by the pointer
	if(check_for_op()){
		_v->set_constant(stof(_s.substr(_operatorindex+1)));
                if(if_sub()){
			_v->set_constant(0 - _v->get_constant());
                }
        }
}


void parser::reverse_string(){						//Converting the string b+ax to ax+b
	if( _varindex == _s.size()-1){
		bool is_op=false;
                string s1,s2;
                int i;                
                for(i=_varindex;i>0;i--){
                    if(_s[i] == '+' || _s[i] == '-'){
		        is_op=true;
                        break;
                    }
                }
                if(is_op){
			if(_s[i] == '+')
	                    s1 = _s.substr(i+1,_varindex-i);
	                else
	                    s1 = _s.substr(i,_varindex-i+1);
			if(s1[0]=='-'){
				_flag=1;
			}
	                s2 = _s.substr(0,i);
	                if(s2[0] == '-'){
	                    _s = s1 + '-' + s2.substr(1,i-1);
	              	}
	               	else{
	 	                 _s = s1 + '+' + s2;					 
			}	           
		     	_varindex = _s.find(_ch);
                }
        }
}

float parser::get_a(){							//Returning the coefficient of the variable
	calc_a();
	return _v -> get_x();
}

float parser::get_b(){							//Returning the constant term
       calc_b();
       return _v -> get_constant();
}
